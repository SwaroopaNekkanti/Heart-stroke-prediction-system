function out = Sigmoid(inp)
out = 1/(1+exp(-inp));
end